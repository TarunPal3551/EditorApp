package editor.avilaksh.com.editorapp.Interface;

import com.zomato.photofilters.imageprocessors.Filter;

/**
 * Created by mahmoud on 1/09/18.
 */

public interface FiltersListFragmentListener {
    void onFilterSelected(Filter filter);

}
