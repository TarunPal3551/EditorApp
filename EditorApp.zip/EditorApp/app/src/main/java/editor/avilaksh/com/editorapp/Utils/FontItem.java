package editor.avilaksh.com.editorapp.Utils;

public class FontItem {
    String fontFamilyName;

    public FontItem() {

    }

    public FontItem(String fontFamilyName) {
        this.fontFamilyName = fontFamilyName;
    }

    public String getFontFamilyName() {
        return fontFamilyName;
    }

    public void setFontFamilyName(String fontFamilyName) {
        this.fontFamilyName = fontFamilyName;
    }
}

