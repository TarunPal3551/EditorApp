package editor.avilaksh.com.editorapp;

public class PostItems {
    public  static  int[] instagram_post_items=new int[]{

      R.drawable.insta

    };
}
